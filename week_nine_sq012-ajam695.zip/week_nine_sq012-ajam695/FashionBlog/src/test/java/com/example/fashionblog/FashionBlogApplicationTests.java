package com.example.fashionblog;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FashionBlogApplicationTests {

    @Test
    void contextLoads() {
    }

}
