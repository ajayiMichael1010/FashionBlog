//package com.example.fashionblog.services;
//
//import com.example.fashionblog.util.ApiResponse;
//
//public interface BlogLikeService {
//    ApiResponse likeOrUnLikePost(Long Id,String postType, Long postTypeId);
//
//}
