package com.example.fashionblog.enums;

public enum Role {
    Admin, User, Anonymous
}
