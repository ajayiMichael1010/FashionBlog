package com.example.fashionblog.services;

import com.example.fashionblog.entities.UserRole;

public interface RoleService {
    UserRole getRoleById(Long Id);
}
