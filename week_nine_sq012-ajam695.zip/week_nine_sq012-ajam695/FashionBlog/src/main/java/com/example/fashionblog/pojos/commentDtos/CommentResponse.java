package com.example.fashionblog.pojos.commentDtos;

public class CommentResponse {
}
