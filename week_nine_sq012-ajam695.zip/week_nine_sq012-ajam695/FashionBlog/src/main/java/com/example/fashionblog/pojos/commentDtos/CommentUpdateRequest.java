package com.example.fashionblog.pojos.commentDtos;

public class CommentUpdateRequest {
    private String comment;
}
